import { Injectable } from '@angular/core';
//import { environment } from '../environments/environment';

@Injectable()
export class Configuration {
	public logo          = 'assets/images/logo.png';
	public duration      = 5000;
	public Alertduration = 1500;
	public BASE_URL      = 'http://apidev.digipace.net/';
}
