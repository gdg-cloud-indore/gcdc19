
@import "assets/vendors/jquery/jquery-3.2.1.min.js";
@import "assets/vendors/bootstrap/bootstrap.bundle.min.js";
@import "assets/vendors/owl-carousel/owl.carousel.min.js";
@import "assets/vendors/Magnific-Popup/jquery.magnific-popup.min.js";
@import "assets/js/jquery.ajaxchimp.min.js";
@import "assets/js/mail-script.js";
@import "assets/js/countdown.js";
@import "assets/js/jquery.magnific-popup.min.js";
@import "assets/js/main.js";